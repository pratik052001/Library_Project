package com.example.demo.model;

public enum BookStatus {
	  USED,
	  FREE,
	  NOTPUBLISHED,
	  PUBLISHED
}
