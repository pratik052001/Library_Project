export class Page {
    size = 0;
    totalElements = 0;
    totalPages = 0;
    page = 0;
    constructor() {
        this.page = 0;
        this.size = 10;
    }
}