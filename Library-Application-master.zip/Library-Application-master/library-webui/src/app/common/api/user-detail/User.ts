export class User {
    public username: string;
    public firstname: string;
    public email: string;
    public lastname: string;
    constructor() { }
  }