export class Author {
    id: number;
    public name: string;
    public surname: string;
    public email: string;
    public phone: string;
    public about: string;
    constructor() { }
  }