export class Student {
    public id: number;
    public fullname: string;
    public tcNo: string;
    public email: string;
    public phone: string;
    public city: string;
    public university: string;
    public department: string;
    public address: string;
    constructor() { }
  }